﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Globalization;
using NPlot;

namespace PolarimeterApp
{
    public partial class Form1 : Form
    {
        SerialPort _serialPort;
        int State;
        int MaxPoints, TakeEachPoint, TakeEachPointNow;
        Int32 value1, value2, value3, value4, value5, value6;
        double time, val1, val2, val3, val4, val5;
        DateTime StartExperiment;
        String FileName;
        String XMinText, XMaxText, YMinText, YMaxText;
        Double XMin, XMax, YMin, YMax;

        StreamWriter OutputFile;
        double YMIN, YMAX;
        LinePlot NPlot1;
        double[] XX, YY;
        int NPoints;
        System.Char[] SerialWriteBuffer;
        int OperationMode;
        bool AutoRescale;

        int MODE_IDLE;
        int MODE_MAIN;
        int SCAN_CELL;

        public Form1()
        {
            MODE_IDLE = -1;
            MODE_MAIN = 0;
            SCAN_CELL = 1;
            State = 0;
            OperationMode = MODE_IDLE;
            InitializeComponent();
            textBox1.Text = "COM4";
            SerialWriteBuffer = new System.Char[1];
            SerialWriteBuffer[0] = 'm';
            AutoRescale = true;
            MaxPoints = 10000;

        }
        private void ChangeOperationMode(int NewMode)
        {
            if (OperationMode == NewMode) return;
            if (NewMode == MODE_IDLE)
            {
                if (OutputFile != null) OutputFile.Close();
                button2.Enabled = false;
                button3.Enabled = false;
                textBox1.Enabled = true;
                timer1.Enabled = false;
                OperationMode = MODE_IDLE;
            }
            if (NewMode == MODE_MAIN)
            {
                SerialWriteBuffer[0] = 'm';
                StartExperiment = DateTime.Now;
                FileName = String.Format("polar{0,4:0000}_{1,2:00}_{2,2:00}-{3,2:00}_{4,2:00}_{5,2:00}.out",
                                                                                StartExperiment.Year,
                                                                                StartExperiment.Month,
                                                                                StartExperiment.Day,
                                                                                StartExperiment.Hour,
                                                                                StartExperiment.Minute,
                                                                                StartExperiment.Second);
                if(OutputFile!=null) OutputFile.Close();

                OutputFile = new StreamWriter(FileName);        // create file
                OutputFile.Close();

                label1.Text = FileName;
                YMIN = 0; YMAX = 0;
                NPlot1 = new LinePlot();
                NPoints = 0;
                AutoRescale = true;
                XX = new double[1];
                YY = new double[1];
                NPlot1.AbscissaData = XX;
                NPlot1.DataSource = YY;
                plotSurface2D1.Clear();
                plotSurface2D1.Add(NPlot1);
                button2.Enabled = true;
                button3.Enabled = true;
                button3.Text = "Scan";
                timer1.Interval = 100;
                timer1.Enabled = true;
                textBox1.Enabled = false;
                OperationMode = MODE_MAIN;
                TakeEachPoint = 1;
                TakeEachPointNow = 0;
            }
            if (NewMode == SCAN_CELL)
            {
                SerialWriteBuffer[0] = 'm';
                StartExperiment = DateTime.Now;
                AutoRescale = false;
                FileName = String.Format("scan{0,4:0000}_{1,2:00}_{2,2:00}-{3,2:00}_{4,2:00}_{5,2:00}.out",
                                                                                StartExperiment.Year,
                                                                                StartExperiment.Month,
                                                                                StartExperiment.Day,
                                                                                StartExperiment.Hour,
                                                                                StartExperiment.Minute,
                                                                                StartExperiment.Second);
                if (OutputFile != null) OutputFile.Close();
                OutputFile = new StreamWriter(FileName);
                OutputFile.Close();

                label1.Text = FileName;
                YMIN = -2.5; YMAX = 2.5;
                NPlot1 = new LinePlot();
                NPoints = 0;
                XX = new double[1];
                YY = new double[1];
                NPlot1.AbscissaData = XX;
                NPlot1.DataSource = YY;
                plotSurface2D1.Clear();
                plotSurface2D1.Add(NPlot1);

                plotSurface2D1.XAxis1.WorldMin = -0.5;
                plotSurface2D1.XAxis1.WorldMax = 10.5;
                plotSurface2D1.YAxis1.WorldMin = -2.5;
                plotSurface2D1.YAxis1.WorldMax = 0.5;

                XMin = -0.5;
                XMax = 10.5;
                YMin = -2.5;
                YMax = 0.5;

                textBox2.Text = YMax.ToString();
                textBox3.Text = YMin.ToString();
                textBox4.Text = XMin.ToString();
                textBox5.Text = XMax.ToString();

                plotSurface2D1.Refresh();
 
                button2.Enabled = true;
                button3.Enabled = false;
 //               button3.Text = "Stop Scan";
                timer1.Interval = 10;
                timer1.Enabled = true;
                textBox1.Enabled = false;
                OperationMode = SCAN_CELL;
            }



        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (State == 0)
            {
// /* // DEBUG   
                // Create a new SerialPort object with default settings.
                _serialPort = new SerialPort();

                _serialPort.PortName = textBox1.Text;
                _serialPort.DataBits = 8;
                _serialPort.Parity = Parity.None;
                _serialPort.StopBits = StopBits.One;
                _serialPort.BaudRate = 9600;
                //            _serialPort.RtsEnable = true;

                // Set the read/write timeouts
                _serialPort.ReadTimeout = 5000;
                _serialPort.WriteTimeout = 5000;
                try
                {
                    _serialPort.Open();
                    toolStripStatusLabel1.Text = DateTime.Now.ToString();
                    toolStripStatusLabel1.Text += ": Opened interface";
                    button1.Text = "Close";
                    State = 1;
                    ChangeOperationMode(MODE_MAIN);
                }
                catch (System.IO.IOException)
                {
                    toolStripStatusLabel1.Text = DateTime.Now.ToString();
                    toolStripStatusLabel1.Text += ": The port is in an invalid state";
                }
                catch (UnauthorizedAccessException)
                {
                    toolStripStatusLabel1.Text = DateTime.Now.ToString();
                    toolStripStatusLabel1.Text += ": Access is denied to the port.";
                }
                catch (ArgumentOutOfRangeException)
                {
                    toolStripStatusLabel1.Text = DateTime.Now.ToString();
                    toolStripStatusLabel1.Text += ": Wrong serial port configuration.";
                }
                catch (ArgumentException)
                {
                    toolStripStatusLabel1.Text = DateTime.Now.ToString();
                    toolStripStatusLabel1.Text += ": Port name not supported.";
                }
                catch (InvalidOperationException)
                {
                    toolStripStatusLabel1.Text = DateTime.Now.ToString();
                    toolStripStatusLabel1.Text += ": Port already open.";
                }
// */ // DEBUG                     
 //               textBox1.Text = "COM4";

//                button1.Text = "Close";
//                State = 1;
//                ChangeOperationMode(MODE_MAIN);
// end DEBUG
            }
            else if (State == 1)
            {
//  DEBUG
                _serialPort.Close();
                button1.Text = "Open";
                toolStripStatusLabel1.Text = DateTime.Now.ToString();
                toolStripStatusLabel1.Text += ": Closed interface";
                State = 0;
                ChangeOperationMode(MODE_IDLE);
            }
        }

        private void ParseString(string InStr)
        {
            String[] words=InStr.Split(' ');

            try
            {
                if (words[0] == "m")
                {
                    ChangeOperationMode(MODE_MAIN);
                    value1 = Int32.Parse(words[1]);
                    value2 = Int32.Parse(words[2]);
                    value3 = Int32.Parse(words[3]);
                    value4 = Int32.Parse(words[4]);
                    value5 = Int32.Parse(words[5]);
                    value6 = Int32.Parse(words[6]);
                    time = (DateTime.Now - StartExperiment).Ticks / 10000000.0;


                    val1 = (value1 - 8388608) * 5000.0 / 16777216.0;
                    val2 = (value2 - 8388608) * 5.0 / 16777216.0;
                    val3 = (value3 - 8388608) * 5.0 / 16777216.0;
                    val4 = (value4 - 8388608) * 5000.0 / 16777216.0;

                    if ((Math.Abs(val2) <= 1.0e-5) || (Math.Abs(val4) <= 1.0e-5)) val5 = 0;
                    else                                      val5 = 8880.0 * val1 / (val2 * val4);

                    label2.Text = value1.ToString();
                    label3.Text = value2.ToString();
                    label4.Text = value3.ToString();
                    label5.Text = value4.ToString();
                    label6.Text = value5.ToString();
                    label7.Text = value6.ToString();

                    label11.Text = val1.ToString();
                    label10.Text = val2.ToString();
                    label9.Text = val3.ToString();
                    label8.Text = val4.ToString();

                    label16.Text = val5.ToString();

                    OutputFile = new StreamWriter(FileName, true);
                    OutputFile.WriteLine(String.Format("{0} {1} {2} {3} {4} {5} {6} {7} ", time, value1, value2, value3, value4, value5, value6, val5));
                    OutputFile.Close();


                    if ((NPoints < MaxPoints)&&(((TakeEachPointNow++) == TakeEachPoint)))
                    {
                            if (val5 < YMIN) YMIN = val5;
                            if (val5 > YMAX) YMAX = val5;
                            NPoints++;
                            Array.Resize(ref XX, NPoints);
                            Array.Resize(ref YY, NPoints);
                            XX[NPoints - 1] = time;
                            YY[NPoints - 1] = val5;
                            NPlot1.DataSource = YY;
                            NPlot1.AbscissaData = XX;
                            plotSurface2D1.Refresh();   // added new points
                            TakeEachPointNow = 0;
                    }
                    if (NPoints == MaxPoints)
                    {
                        for (int i = 0; i < NPoints / 2; i++)
                        {
                            XX[i] = XX[2 * i];
                            YY[i] = YY[2 * i];
                        }
                        NPoints /= 2;
                        TakeEachPoint *= 2;
                        TakeEachPointNow = 0;
                        Array.Resize(ref XX, NPoints);
                        Array.Resize(ref YY, NPoints);
                    }
                    if ((time > plotSurface2D1.XAxis1.WorldMax) && AutoRescale) PlotRescale();
// DEBUG 
                   _serialPort.Write(SerialWriteBuffer, 0, 1);
                }

                if (words[0] == "s")
                {
                    ChangeOperationMode(SCAN_CELL);
                    value6 = Int32.Parse(words[1]);
                    value3 = Int32.Parse(words[2]);
                    if (value3 == 16777215) return;
                    if (value3 == 0) return;

                    time = (DateTime.Now - StartExperiment).Ticks / 10000000.0;


                    val1 = value6 * 10.0 / 1024;
                    val3 = (value3 - 8388608) * 5.0 / 16777216.0;

                    //                val5 = 100.0 * val1 / (val2 * val4);

                    label2.Text = "-";
                    label3.Text = "-";
                    label4.Text = value3.ToString();
                    label5.Text = "-";
                    label6.Text = value6.ToString();
                    label7.Text = "-";

                    label11.Text = val1.ToString();
                    label10.Text = "-";
                    label9.Text = val3.ToString();
                    label8.Text = "-";

                    label16.Text = "-";

                    OutputFile = new StreamWriter(FileName, true);
                    OutputFile.WriteLine(String.Format("{0} {1} {2} {3} {4} ", value6, value3, val1, val3, time));
                    OutputFile.Close();


                    if (NPoints <= MaxPoints)
                    {
                        if (val3 < YMIN) YMIN = val3;
                        if (val3 > YMAX) YMAX = val3;
                        NPoints++;
                        Array.Resize(ref XX, NPoints);
                        Array.Resize(ref YY, NPoints);
                        XX[NPoints - 1] = val1;
                        YY[NPoints - 1] = val3;
                        NPlot1.DataSource = YY;
                        NPlot1.AbscissaData = XX;
                        plotSurface2D1.Refresh();  // added new points
                    }
                    //                if (time > plotSurface2D1.XAxis1.WorldMax) PlotRescale();
                }
            }
            catch (System.FormatException)
            {
            }

        }

        private void PlotRescale()
        {
            if (AutoRescale)
            {
                if (OperationMode == MODE_MAIN)
                {
                    plotSurface2D1.XAxis1.WorldMin = 0;
                    plotSurface2D1.XAxis1.WorldMax = time;
                    plotSurface2D1.YAxis1.WorldMin = YMIN;
                    plotSurface2D1.YAxis1.WorldMax = YMAX;

                    plotSurface2D1.XAxis1.WorldMin -= plotSurface2D1.XAxis1.WorldLength * 0.1;
                    plotSurface2D1.XAxis1.WorldMax += plotSurface2D1.XAxis1.WorldLength * 0.5;
                    plotSurface2D1.YAxis1.WorldMin -= plotSurface2D1.YAxis1.WorldLength * 0.1;
                    plotSurface2D1.YAxis1.WorldMax += plotSurface2D1.YAxis1.WorldLength * 0.1;

                    textBox2.Text = plotSurface2D1.YAxis1.WorldMax.ToString("F0");
                    textBox3.Text = plotSurface2D1.YAxis1.WorldMin.ToString("F0");
                    textBox4.Text = plotSurface2D1.XAxis1.WorldMin.ToString("F0");
                    textBox5.Text = plotSurface2D1.XAxis1.WorldMax.ToString("F0");

                    XMin = plotSurface2D1.XAxis1.WorldMin;
                    XMax = plotSurface2D1.XAxis1.WorldMax;
                    YMin = plotSurface2D1.YAxis1.WorldMin;
                    YMax = plotSurface2D1.YAxis1.WorldMax;

                    textBox2.BackColor = SystemColors.Menu;
                    textBox3.BackColor = SystemColors.Menu;
                    textBox4.BackColor = SystemColors.Menu;
                    textBox5.BackColor = SystemColors.Menu;

                    plotSurface2D1.Refresh();
                }
                if (OperationMode == SCAN_CELL)
                {
                    plotSurface2D1.XAxis1.WorldMin = -0.5;
                    plotSurface2D1.XAxis1.WorldMax = 10.5;
                    plotSurface2D1.YAxis1.WorldMin = -2.5;
                    plotSurface2D1.YAxis1.WorldMax = 0.5;

                    XMin = -0.5;
                    XMax = 10.5;
                    YMin = -2.5;
                    YMax = 0.5;

                    textBox2.Text = YMax.ToString("F0");
                    textBox3.Text = YMin.ToString("F0");
                    textBox4.Text = XMin.ToString("F0");
                    textBox5.Text = XMax.ToString("F0");
 
                    textBox2.BackColor = SystemColors.Menu;
                    textBox3.BackColor = SystemColors.Menu;
                    textBox4.BackColor = SystemColors.Menu;
                    textBox5.BackColor = SystemColors.Menu;

                    plotSurface2D1.Refresh();
                }
            }
            else
            {
                plotSurface2D1.XAxis1.WorldMin = XMin;
                plotSurface2D1.XAxis1.WorldMax = XMax;
                plotSurface2D1.YAxis1.WorldMin = YMin;
                plotSurface2D1.YAxis1.WorldMax = YMax;

                textBox2.BackColor = SystemColors.Window;
                textBox3.BackColor = SystemColors.Window;
                textBox4.BackColor = SystemColors.Window;
                textBox5.BackColor = SystemColors.Window;

                plotSurface2D1.Refresh();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label18.Text = ((DateTime.Now - StartExperiment).Ticks/10000000.0).ToString();
// /* //DEBUG
            if (_serialPort.IsOpen)
            {
                if (_serialPort.BytesToRead>0)
                {
                    try
                    {
                        ParseString( _serialPort.ReadLine());
                    }
                    catch (TimeoutException)
                    {
                        toolStripStatusLabel1.Text = "Timeout";
                    } 
                }
            }
 // */ // DEBUG
 //           ParseString("m 8312537 6100722 4193604 8887691 369 376");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            AutoRescale = true;
            PlotRescale();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (OperationMode == MODE_MAIN)
            {
                SerialWriteBuffer[0] = 's';
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            AutoRescale = false;
            try
            {
                YMax = Double.Parse(textBox2.Text);
            }
            catch (System.FormatException) { textBox2.Text = YMax.ToString("F0"); }
            try
            {
                YMin = Double.Parse(textBox3.Text);
            }
            catch (System.FormatException) { textBox3.Text = YMin.ToString("F0"); }
            try
            {
                XMin = Double.Parse(textBox4.Text);
            }
            catch (System.FormatException) { textBox4.Text = XMin.ToString("F0"); }
            try
            {
                XMax = Double.Parse(textBox5.Text);
            }
            catch (System.FormatException) { textBox5.Text = XMax.ToString("F0"); }
            PlotRescale();

        }





    }
}
